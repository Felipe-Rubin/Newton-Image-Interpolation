/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOPen;
    QAction *actionSave;
    QAction *openImage;
    QAction *saveImage;
    QAction *actionAbout;
    QAction *actionFiniteTable;
    QAction *actionPixelValues;
    QWidget *centralWidget;
    QGridLayout *gridLayout_3;
    QGroupBox *configurationBox;
    QGridLayout *gridLayout;
    QLabel *resizeLabel;
    QSpinBox *interpolationDegree;
    QPushButton *confirmButton;
    QSpinBox *resizePercentage;
    QLabel *interpolationLabel;
    QGroupBox *IDHRBox;
    QGridLayout *gridLayout_2;
    QLabel *bitdepthValue;
    QLabel *heightValue;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *channelsValue;
    QLabel *colorTypeValue;
    QLabel *widthValue;
    QLabel *label_5;
    QLabel *label_4;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QStatusBar *statusBar;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuView;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(900, 500);
        MainWindow->setMinimumSize(QSize(900, 500));
        MainWindow->setStyleSheet(QStringLiteral("background-color: #E6DED6"));
        actionOPen = new QAction(MainWindow);
        actionOPen->setObjectName(QStringLiteral("actionOPen"));
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        openImage = new QAction(MainWindow);
        openImage->setObjectName(QStringLiteral("openImage"));
        openImage->setCheckable(false);
        saveImage = new QAction(MainWindow);
        saveImage->setObjectName(QStringLiteral("saveImage"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionFiniteTable = new QAction(MainWindow);
        actionFiniteTable->setObjectName(QStringLiteral("actionFiniteTable"));
        actionPixelValues = new QAction(MainWindow);
        actionPixelValues->setObjectName(QStringLiteral("actionPixelValues"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout_3 = new QGridLayout(centralWidget);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        configurationBox = new QGroupBox(centralWidget);
        configurationBox->setObjectName(QStringLiteral("configurationBox"));
        QFont font;
        font.setPointSize(19);
        configurationBox->setFont(font);
        configurationBox->setStyleSheet(QLatin1String("\n"
"	background-color: none;\n"
""));
        gridLayout = new QGridLayout(configurationBox);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        resizeLabel = new QLabel(configurationBox);
        resizeLabel->setObjectName(QStringLiteral("resizeLabel"));
        QFont font1;
        font1.setPointSize(15);
        font1.setUnderline(false);
        resizeLabel->setFont(font1);
        resizeLabel->setAutoFillBackground(false);
        resizeLabel->setFrameShape(QFrame::NoFrame);
        resizeLabel->setFrameShadow(QFrame::Plain);

        gridLayout->addWidget(resizeLabel, 2, 0, 1, 1);

        interpolationDegree = new QSpinBox(configurationBox);
        interpolationDegree->setObjectName(QStringLiteral("interpolationDegree"));
        interpolationDegree->setMaximumSize(QSize(16777209, 16777215));
        interpolationDegree->setStyleSheet(QLatin1String("Qt::WheelFocus{\n"
"	ignore;\n"
"}"));
        interpolationDegree->setValue(3);

        gridLayout->addWidget(interpolationDegree, 0, 1, 1, 1);

        confirmButton = new QPushButton(configurationBox);
        confirmButton->setObjectName(QStringLiteral("confirmButton"));
        confirmButton->setStyleSheet(QLatin1String("QPushButton{\n"
"    background-color: #453D2B; \n"
"    border: none;\n"
"   color: white;\n"
"    text-align: center;\n"
"    font-size: 24px;\n"
"}\n"
"\n"
""));

        gridLayout->addWidget(confirmButton, 3, 0, 1, 2);

        resizePercentage = new QSpinBox(configurationBox);
        resizePercentage->setObjectName(QStringLiteral("resizePercentage"));
        resizePercentage->setStyleSheet(QLatin1String("QSpinBox:{\n"
"	font-size: 20px;\n"
"}"));
        resizePercentage->setMaximum(999999999);
        resizePercentage->setValue(100);

        gridLayout->addWidget(resizePercentage, 2, 1, 1, 1);

        interpolationLabel = new QLabel(configurationBox);
        interpolationLabel->setObjectName(QStringLiteral("interpolationLabel"));
        QFont font2;
        font2.setPointSize(15);
        font2.setUnderline(false);
        font2.setKerning(true);
        interpolationLabel->setFont(font2);
        interpolationLabel->setAutoFillBackground(false);
        interpolationLabel->setFrameShape(QFrame::NoFrame);
        interpolationLabel->setFrameShadow(QFrame::Plain);

        gridLayout->addWidget(interpolationLabel, 0, 0, 1, 1);


        gridLayout_3->addWidget(configurationBox, 1, 0, 1, 1);

        IDHRBox = new QGroupBox(centralWidget);
        IDHRBox->setObjectName(QStringLiteral("IDHRBox"));
        IDHRBox->setStyleSheet(QLatin1String("QGroupBox{\n"
"background-color: none;\n"
"font-size: 16px\n"
"}\n"
"QLabel{\n"
"	background-color: none;\n"
"	font-size: 16px;\n"
"}"));
        gridLayout_2 = new QGridLayout(IDHRBox);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        bitdepthValue = new QLabel(IDHRBox);
        bitdepthValue->setObjectName(QStringLiteral("bitdepthValue"));

        gridLayout_2->addWidget(bitdepthValue, 2, 2, 1, 1);

        heightValue = new QLabel(IDHRBox);
        heightValue->setObjectName(QStringLiteral("heightValue"));

        gridLayout_2->addWidget(heightValue, 0, 2, 1, 1);

        label_8 = new QLabel(IDHRBox);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout_2->addWidget(label_8, 2, 0, 1, 1);

        label_9 = new QLabel(IDHRBox);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_2->addWidget(label_9, 3, 0, 1, 1);

        label_10 = new QLabel(IDHRBox);
        label_10->setObjectName(QStringLiteral("label_10"));

        gridLayout_2->addWidget(label_10, 4, 0, 1, 2);

        channelsValue = new QLabel(IDHRBox);
        channelsValue->setObjectName(QStringLiteral("channelsValue"));

        gridLayout_2->addWidget(channelsValue, 3, 2, 1, 1);

        colorTypeValue = new QLabel(IDHRBox);
        colorTypeValue->setObjectName(QStringLiteral("colorTypeValue"));

        gridLayout_2->addWidget(colorTypeValue, 4, 2, 1, 1);

        widthValue = new QLabel(IDHRBox);
        widthValue->setObjectName(QStringLiteral("widthValue"));

        gridLayout_2->addWidget(widthValue, 1, 2, 1, 1);

        label_5 = new QLabel(IDHRBox);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout_2->addWidget(label_5, 1, 0, 1, 1);

        label_4 = new QLabel(IDHRBox);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout_2->addWidget(label_4, 0, 0, 1, 1);


        gridLayout_3->addWidget(IDHRBox, 2, 0, 1, 1);

        scrollArea = new QScrollArea(centralWidget);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContentsOnFirstShow);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 565, 428));
        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout_3->addWidget(scrollArea, 1, 1, 2, 1);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 900, 22));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuFile->setTearOffEnabled(false);
        menuView = new QMenu(menuBar);
        menuView->setObjectName(QStringLiteral("menuView"));
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuView->menuAction());
        menuFile->addAction(openImage);
        menuFile->addAction(saveImage);
        menuView->addAction(actionFiniteTable);
        menuView->addAction(actionPixelValues);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionOPen->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        actionSave->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        openImage->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        saveImage->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        actionAbout->setText(QApplication::translate("MainWindow", "About", Q_NULLPTR));
        actionFiniteTable->setText(QApplication::translate("MainWindow", "FiniteTable", Q_NULLPTR));
        actionPixelValues->setText(QApplication::translate("MainWindow", "PixelValues", Q_NULLPTR));
        configurationBox->setTitle(QApplication::translate("MainWindow", "Configuration", Q_NULLPTR));
        resizeLabel->setText(QApplication::translate("MainWindow", "Resize Percentage", Q_NULLPTR));
        confirmButton->setText(QApplication::translate("MainWindow", "Confirm", Q_NULLPTR));
        resizePercentage->setSuffix(QApplication::translate("MainWindow", "%", Q_NULLPTR));
        resizePercentage->setPrefix(QString());
        interpolationLabel->setText(QApplication::translate("MainWindow", "Interpolation Degree", Q_NULLPTR));
        IDHRBox->setTitle(QApplication::translate("MainWindow", "IDHR Information", Q_NULLPTR));
        bitdepthValue->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        heightValue->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Bit-Depth", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "Channels", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "Color Type", Q_NULLPTR));
        channelsValue->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        colorTypeValue->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        widthValue->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Width", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Height", Q_NULLPTR));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", Q_NULLPTR));
        menuView->setTitle(QApplication::translate("MainWindow", "View", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
